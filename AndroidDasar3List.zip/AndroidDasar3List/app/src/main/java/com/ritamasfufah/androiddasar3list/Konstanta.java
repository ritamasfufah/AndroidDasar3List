package com.ritamasfufah.androiddasar3list;

public class Konstanta {
    public static final String DATANAMA = "datanama" ;
    public static final String DATAGAMBAR = "datagambar";
}
